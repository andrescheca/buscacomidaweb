$(function () {
	console.log('Página cargada');
});